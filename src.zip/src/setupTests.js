
// jest-dom adds custom jest matchers for asserting on DOM nodes.
// allows you to do things like:
// expect(element).toHaveTextContent(/react/i)
// learn more: https://github.com/testing-library/jest-dom
import '@testing-library/jest-dom';https://github.com/apna-college/Zoom/commit/243f72d7fc18aa11be7b8ae1c0ccb30036c71178#diff-3a8c5a8347827277ca8eb529ec90ffc5e52fc5ff5de9b5b0f840b6c29a22bb13https://github.com/apna-college/Zoom/commit/243f72d7fc18aa11be7b8ae1c0ccb30036c71178#diff-3a8c5a8347827277ca8eb529ec90ffc5e52fc5ff5de9b5b0f840b6c29a22bb13

